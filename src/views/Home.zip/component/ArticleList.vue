<template>
  <div>文章</div>
</template>

<script>
export default {
  props: {
    id: {
      type: [String, Number],
      require: true
    }
  }
}
</script>

<style></style>
